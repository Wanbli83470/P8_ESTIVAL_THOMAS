$(document).ready(function(){
    alert("Une alerte");
    console.log("Une alerte");

    $("#footer").click(function(){
        alert("La detection Jquery fonctionne");
    });
});


